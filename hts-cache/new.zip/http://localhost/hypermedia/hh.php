<!DOCTYPE html>
<html lang="en">
  
      <head>
        <meta charset="utf-8">
        <meta name="description" content="Tim Italy Website design">
        <meta name="keywords" content="TIM,HYPERMEDIA">
        <meta name="author" content="Hamidreza Hanafi">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Huts and Hostels</title>

        <!-- Bootstrap -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <style>
          .carousel-inner > .item > img,
          .carousel-inner > .item > a > img {
              width: 70%;
              margin: auto;
          }
          </style>
    </head>  
  <body>
    <div class="container">

            <div class="row">
        <a href="index.php">
          <div class="col-md-3">
            <img src="images/logo.png" height="200" width="250" style="margin-right:5px;" />
          </div>
          <div class="col-md-9">
            <img src="images/header.jpg" width="750" height="200" />
          </div>
        </a>
      </div>

      <div class="row">
          <div class="col-md-5ths menuitem ">
          <a href="trails.php">Trails</a></div>
          <div class="col-md-5ths menuitem "><a href="territories.php">Our Territory</a></div>
          <div class="col-md-5ths menuitem selected"><a href="hh.php">Huts and Hostels</a></div>
          <div class="col-md-5ths menuitem "><a href="aboutus.php">About us</a></div>
          <div class="col-md-5ths menuitem "><a href="gethere.php">How to get here</a></div>
      </div>      <div class="row">
                <div class="col-md-4 menuitem">
        <a href="hhdetail.php?id=1">Guesthouse of Mavignola</a>        </div>
                <div class="col-md-4 menuitem">
        <a href="hhdetail.php?id=2">Guesthouse of Valagola</a>        </div>
                <div class="col-md-4 menuitem">
        Guesthouse Maso Doss        </div>
              </div>
      <div class="row">
        <div class="col-md-11" style="margin-top:20px; margin-left:20px">
          <p>
          <img src="images/freemans-campground-03.jpg" width="470" height="350" align="right" style="margin:0px 0px 20px 20px" /> 
          <span><p class="bodytext"><big>The Park has two hostels, one situated at Sant'Antonio di Mavignola and one in the heart of the Brenta at Valagola near the lkae with the same name. The Park recommends you to use accommodation with the Qualit&agrave; Parco logo.  Structures with the Qualit&agrave; Parco logo adopt a number of management rules aimed at saving energy and water, rationalising use of resources and making what they offer more typical.&nbsp;  Participants in this project are aware of the importance of their role and committed to maintaining the landscape intact and constantly attenuating their environmental impact.  Hotels, garn&igrave; and campsites await you to help you discover the fascination of unspoilt nature and a unique landscape where you can enjoy your holiday in respect of the local area, making the most of your experience by discovering the environment, history and traditions of one of the most evocative holiday<br />destinations in the Alps.<br />Instead, for the most adventurous of you, &nbsp;the park has a big campground, which can guest around 100 tents; we are gonna supply electricity for all your needs, and all<br /> the information you want to know, contact us to save a spot for you!<br /></big></p></span>
          </p>
        <ul style="font-size:20px">
        <li><a href="hhdetail.php?id=1">Guesthouse of Mavignola</a></li><li><a href="hhdetail.php?id=2">Guesthouse of Valagola</a></li><li>Guesthouse Maso Doss</li>        </div>
      </div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>