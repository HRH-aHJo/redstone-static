<!DOCTYPE html>
<html lang="en">
  
      <head>
        <meta charset="utf-8">
        <meta name="description" content="Tim Italy Website design">
        <meta name="keywords" content="TIM,HYPERMEDIA">
        <meta name="author" content="Hamidreza Hanafi">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>How to get here</title>

        <!-- Bootstrap -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <style>
          .carousel-inner > .item > img,
          .carousel-inner > .item > a > img {
              width: 70%;
              margin: auto;
          }
          </style>
    </head>  
  <body>
    <div class="container">

            <div class="row">
        <a href="index.php">
          <div class="col-md-3">
            <img src="images/logo.png" height="200" width="250" style="margin-right:5px;" />
          </div>
          <div class="col-md-9">
            <img src="images/header.jpg" width="750" height="200" />
          </div>
        </a>
      </div>

      <div class="row">
          <div class="col-md-5ths menuitem ">
          <a href="trails.php">Trails</a></div>
          <div class="col-md-5ths menuitem "><a href="territories.php">Our Territory</a></div>
          <div class="col-md-5ths menuitem "><a href="hh.php">Huts and Hostels</a></div>
          <div class="col-md-5ths menuitem "><a href="aboutus.php">About us</a></div>
          <div class="col-md-5ths menuitem selected"><a href="gethere.php">How to get here</a></div>
      </div>      <div class="row">
        <div class="col-md-10 col-md-offset-1">
          <div class="aboutustitle">
          How to get here          </div>
          <div class="aboutusbody">
          <div>
<p><img src="images/RTEmagicC_come_raggiungerci_01.jpg.jpg" alt="" width="220" height="200" align="right" /></p>
<p>Giudicarie side:<br />From Trento, take the Gardesana Occidentale SS 45 trunk road to Sarche, then continue to Comano Terme and Tione (SS 237). Just before Comano Terme, there is a turning for the southern part of the Brenta Group (Val d&rsquo;Ambi&eacute;z and Val d&rsquo;Algone - SS 421). From Tione, head south on the SS 237 for the valleys of Breguzzo and Daone-Fumo. Head north (SS 239) for the Val Rendena. After Strembo (Park Headquarters), continue for 7 km and the Val Genova begins at Caris&ograve;lo. All towns and villages in these valleys are connected to the provincial capital, Trento, by public transport.</p>
<p>&nbsp;</p>
</div>
<div><img style="margin-right: 20px;" src="images/Villa_Santi_h.jpg" alt="" width="220" height="200" align="left" />
<p>Val di Non and Val di Sole side:</p>
<p>From Trento, head north on the Brennero SS 12 trunk road as far as San Michele all&rsquo;Adige (A22 exit). Continue on the SS 43 and at Rocchetta you enter the Val di Non. Follow the SP 73 provincial road on the right of the Noce river to Tuenno (start of the Val di Tovel) and then Cles.  Just after Rocchetta there is a turning for Andalo, Molveno and the Altopiano della Paganella (SS 421), eastern access to the central chain of the Brenta and the Campa subgroup.  After Cles, the bridge over the Mostizzolo on the Noce river marks the boundary between the Val di Non and the Val di Sole. Access to the north Brenta chain is from Mal&eacute; and Dimaro.  Access to the Presanella Group is from the high Val di Sole.</p>
</div>          </div>
        </div>
      </div>
      
    </div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>