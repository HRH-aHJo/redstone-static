<!DOCTYPE html>
<html lang="en">
  
      <head>
        <meta charset="utf-8">
        <meta name="description" content="Tim Italy Website design">
        <meta name="keywords" content="TIM,HYPERMEDIA">
        <meta name="author" content="Hamidreza Hanafi">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>About us</title>

        <!-- Bootstrap -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <style>
          .carousel-inner > .item > img,
          .carousel-inner > .item > a > img {
              width: 70%;
              margin: auto;
          }
          </style>
    </head>  
  <body>
    <div class="container">

            <div class="row">
        <a href="index.php">
          <div class="col-md-3">
            <img src="images/logo.png" height="200" width="250" style="margin-right:5px;" />
          </div>
          <div class="col-md-9">
            <img src="images/header.jpg" width="750" height="200" />
          </div>
        </a>
      </div>

      <div class="row">
          <div class="col-md-5ths menuitem ">
          <a href="trails.php">Trails</a></div>
          <div class="col-md-5ths menuitem "><a href="territories.php">Our Territory</a></div>
          <div class="col-md-5ths menuitem "><a href="hh.php">Huts and Hostels</a></div>
          <div class="col-md-5ths menuitem selected"><a href="aboutus.php">About us</a></div>
          <div class="col-md-5ths menuitem "><a href="gethere.php">How to get here</a></div>
      </div>      <div class="row">
        <div class="col-md-4 menuitem selected">
          <a href="aboutus.php">The Park at a glance</a>
        </div>
        <div class="col-md-4 menuitem ">
          <a href="aboutus.php?page=history">History</a>
        </div>
        <div class="col-md-4 menuitem ">
          <a href="aboutus.php?page=rules">Rules</a>
        </div>
      </div>
      <div class="row">
        <div class="col-md-10 col-md-offset-1">
          <div class="aboutustitle">
          Redstone Park          </div>
          <div class="aboutusbody">
          Redstone Park is the largest protected area of Trentino. Located in the western part of Trentino Province - Italy, it is 620,517 km^2 wide: it includes Adamello and Brenta mountainous groups, divided by Rendena Valley and bordered by Non Valley, Sole Valley and Giudicarie Valley. It is endowed with 80 lakes and with Adamello Glacier, one of the largest glaciers in Europe. Its fauna is among the richest of the Alps and includes all animal species which find their habitat on the mountains, bear and steinbock as well. Rich woods and meadows, fruits and flowers which are rare to find, thousands of insects, birds and other animals whose life is determinant for the biological equilibria of the Park and of the Earth, need now more than ever to be protected, and with Your help too.          </div>
        </div>
      </div>
      
    </div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>