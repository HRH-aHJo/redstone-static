<!DOCTYPE html>
<html lang="en">
  
      <head>
        <meta charset="utf-8">
        <meta name="description" content="Tim Italy Website design">
        <meta name="keywords" content="TIM,HYPERMEDIA">
        <meta name="author" content="Hamidreza Hanafi">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Territories</title>

        <!-- Bootstrap -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <style>
          .carousel-inner > .item > img,
          .carousel-inner > .item > a > img {
              width: 70%;
              margin: auto;
          }
          </style>
    </head>  
  <body>
    <div class="container">

            <div class="row">
        <a href="index.php">
          <div class="col-md-3">
            <img src="images/logo.png" height="200" width="250" style="margin-right:5px;" />
          </div>
          <div class="col-md-9">
            <img src="images/header.jpg" width="750" height="200" />
          </div>
        </a>
      </div>

      <div class="row">
          <div class="col-md-5ths menuitem ">
          <a href="trails.php">Trails</a></div>
          <div class="col-md-5ths menuitem selected"><a href="territories.php">Our Territory</a></div>
          <div class="col-md-5ths menuitem "><a href="hh.php">Huts and Hostels</a></div>
          <div class="col-md-5ths menuitem "><a href="aboutus.php">About us</a></div>
          <div class="col-md-5ths menuitem "><a href="gethere.php">How to get here</a></div>
      </div>      <div class="row">
                <div class="col-md-3 menuitem">
        <a href="territorycategory.php?id=1">Environment</a>        </div>
                <div class="col-md-3 menuitem">
        <a href="territorycategory.php?id=2">Animals</a>        </div>
                <div class="col-md-3 menuitem">
        <a href="territorycategory.php?id=3">Plants</a>        </div>
                <div class="col-md-3 menuitem">
        Culture        </div>
              </div>
      <div class="row" style="margin-top:20px;margin-bottom:20px">
        <div class="col-md-10 col-md-offset-1"> 
        <h3 style="margin-left:40px;">
        Where?
        </h3>
        <div>The Adamello Brenta Nature Park is in the Rhaetian Alps, the Italian central southern part of the Alps.  Located in the west of the Trentino between the Val Giudicarie, the Val di Non and the Val di Sole, it extends over two separate geomorphologic areas - the Brenta Dolomites Group and the granite Adamello-Presanello massif.  The two mountain ranges are separated by the Val Rendena run through by the Sarca river. </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-11 col-md-offset-1"> 
        <ul style="font-size:20px">
        <li><a href="territorycategory.php?id=1">Environment</a></li><li><a href="territorycategory.php?id=2">Animals</a></li><li><a href="territorycategory.php?id=3">Plants</a></li><li>Culture</li>        </ul>
        </div>
      </div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>