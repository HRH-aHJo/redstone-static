<!DOCTYPE html>
<html lang="en">
  
      <head>
        <meta charset="utf-8">
        <meta name="description" content="Tim Italy Website design">
        <meta name="keywords" content="TIM,HYPERMEDIA">
        <meta name="author" content="Hamidreza Hanafi">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Trails</title>

        <!-- Bootstrap -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <style>
          .carousel-inner > .item > img,
          .carousel-inner > .item > a > img {
              width: 70%;
              margin: auto;
          }
          </style>
    </head>  
  <body>
    <div class="container">

            <div class="row">
        <a href="index.php">
          <div class="col-md-3">
            <img src="images/logo.png" height="200" width="250" style="margin-right:5px;" />
          </div>
          <div class="col-md-9">
            <img src="images/header.jpg" width="750" height="200" />
          </div>
        </a>
      </div>

      <div class="row">
          <div class="col-md-5ths menuitem selected">
          <a href="trails.php">Trails</a></div>
          <div class="col-md-5ths menuitem "><a href="territories.php">Our Territory</a></div>
          <div class="col-md-5ths menuitem "><a href="hh.php">Huts and Hostels</a></div>
          <div class="col-md-5ths menuitem "><a href="aboutus.php">About us</a></div>
          <div class="col-md-5ths menuitem "><a href="gethere.php">How to get here</a></div>
      </div>      <div class="row">
                <div class="col-md-2 menuitem">
        <a href="traildifficulty.php?id=1">Easy</a>        </div>
                <div class="col-md-2 menuitem">
        Moderate        </div>
                <div class="col-md-2 menuitem">
        <a href="traildifficulty.php?id=3">Challenging</a>        </div>
                <div class="col-md-2 menuitem">
        Difficult        </div>
                <div class="col-md-2 menuitem">
        <a href="traildifficulty.php?id=5">Very difficult</a>        </div>
                <div class="col-md-2 menuitem">
        Extreme        </div>
              </div>
      <div class="row" style="margin-top:20px;margin-bottom:20px">
        <span style="margin-left:40px;">
        SELECT DIFFICULTY OF THE TRAIL
        </span>
      </div>
      <div class="row">
                <div class="col-md-5 col-md-offset-1">
          <div>
            <a href="traildifficulty.php?id=1">Easy</a>          </div>
          <div>
          <ul>
<li>for young and elderly</li>
<li>someone in fair hiking condition</li>
<li>trails are generally in good condition</li>
<li>very little elevation gain</li>
</ul>          </div>
        </div>
                <div class="col-md-5 col-md-offset-1">
          <div>
            Moderate          </div>
          <div>
          <ul>
<li>someone in good hiking condition</li>
<li>increased mileage</li>
<li>trails are generally in good condition</li>
<li>moderate elevation gain</li>
</ul>          </div>
        </div>
                <div class="col-md-5 col-md-offset-1">
          <div>
            <a href="traildifficulty.php?id=3">Challenging</a>          </div>
          <div>
          <ul>
<li>someone in good hiking condition</li>
<li>increased mileage</li>
<li>trails are generally in good condition</li>
<li>significant elevation gain</li>
</ul>          </div>
        </div>
                <div class="col-md-5 col-md-offset-1">
          <div>
            Difficult          </div>
          <div>
          <ul>
<li>someone in excellent hiking condition</li>
<li>significant increase in mileage</li>
<li>trails are generally in good condition</li>
<li>significant elevation gain</li>
</ul>          </div>
        </div>
                <div class="col-md-5 col-md-offset-1">
          <div>
            <a href="traildifficulty.php?id=5">Very difficult</a>          </div>
          <div>
          <ul>
<li>someone in excellent hiking condition</li>
<li>significant increase in mileage</li>
<li>trails are not always in good condition</li>
<li>significant elevation gain</li>
</ul>          </div>
        </div>
                <div class="col-md-5 col-md-offset-1">
          <div>
            Extreme          </div>
          <div>
          <ul>
<li>someone in exceptional hiking/climbing condition</li>
<li>significant increase in mileage</li>
<li>trails are not always available</li>
<li>extreme elevation gain</li>
</ul>          </div>
        </div>
              </div>
      <div class="row">
        <img src="images/hiking-feet-fall-1240.jpg" height="190" width="1024" />
      </div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>