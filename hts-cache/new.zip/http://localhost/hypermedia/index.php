<!DOCTYPE html>
<html lang="en">
  
      <head>
        <meta charset="utf-8">
        <meta name="description" content="Tim Italy Website design">
        <meta name="keywords" content="TIM,HYPERMEDIA">
        <meta name="author" content="Hamidreza Hanafi">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Home</title>

        <!-- Bootstrap -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <style>
          .carousel-inner > .item > img,
          .carousel-inner > .item > a > img {
              width: 70%;
              margin: auto;
          }
          </style>
    </head>  
  <body>
    <div class="container">

            <div class="row">
        <a href="index.php">
          <div class="col-md-3">
            <img src="images/logo.png" height="200" width="250" style="margin-right:5px;" />
          </div>
          <div class="col-md-9">
            <img src="images/header.jpg" width="750" height="200" />
          </div>
        </a>
      </div>

      <div class="row">
          <div class="col-md-5ths menuitem <br />
<b>Notice</b>:  Undefined variable: selected_top_page in <b>/home/hrh/www/hypermedia/header.php</b> on line <b>13</b><br />
">
          <a href="trails.php">Trails</a></div>
          <div class="col-md-5ths menuitem <br />
<b>Notice</b>:  Undefined variable: selected_top_page in <b>/home/hrh/www/hypermedia/header.php</b> on line <b>15</b><br />
"><a href="territories.php">Our Territory</a></div>
          <div class="col-md-5ths menuitem <br />
<b>Notice</b>:  Undefined variable: selected_top_page in <b>/home/hrh/www/hypermedia/header.php</b> on line <b>16</b><br />
"><a href="hh.php">Huts and Hostels</a></div>
          <div class="col-md-5ths menuitem <br />
<b>Notice</b>:  Undefined variable: selected_top_page in <b>/home/hrh/www/hypermedia/header.php</b> on line <b>17</b><br />
"><a href="aboutus.php">About us</a></div>
          <div class="col-md-5ths menuitem <br />
<b>Notice</b>:  Undefined variable: selected_top_page in <b>/home/hrh/www/hypermedia/header.php</b> on line <b>18</b><br />
"><a href="gethere.php">How to get here</a></div>
      </div>
      <div class="row">
        <div class="col-md-4">
          <div class="col-md-12 mainitem news">
            <h4>
            NEWS
            </h4>
                        <div>
              <span style="font-weight:bold">
                2016-09-28 :
              </span>
              <span>
                The park will be closed, due to some special maintenance needed by some of our buildings.              </span>
              <div>
                              </div>
            </div>
                        <div>
              <span style="font-weight:bold">
                2016-08-25 :
              </span>
              <span>
                We are happy to welcome to our family Yoghi, a newborn bear.              </span>
              <div>
                <img src='images/00-black-bear-cub-vladivostok-russia-01-27-02-15.jpg'' width=200 height=200 />              </div>
            </div>
                      </div>
        </div>
        <div class="col-md-4 ">
          <div class="col-md-12 mainitem weather">
            <h4>WEATHER</h4>
            <div>Today:</div>
            <div><img src="images/weather today.png" /></div>
            <div>Next days:</div>
            <div><img src="images/weather next.png" /></div>
            <div><img src="images/weather next2.png" style="margin-top:5px;" /></div>
          </div>
        </div>
        <div class="col-md-4 ">
          <div class="col-md-12 mainitem">
            <h4>
              WELCOME TO THE REDSTONE PARK OFFICIAL SITE
            </h4>
            <div style="text-align:left">
              <div>Find out more about</div>
              <div>our trails: <a href="trails.php">here</a></div>
              <div>our territory: <a href="territories.php">here</a></div>
              <div>our huts and hotels: <a href="hh.php">here</a></div>
              <div>aboutus: <a href="aboutus.php">here</a></div>
              <div>how to get here: <a href="gethere.php">here</a></div>
              <div>Enjoy!</div>
            </div>
          </div>
          <div class="col-md-12 mainitem">
            <div>DOWNLOAD THE MAP OF THE PARK</div>
            <div>Here: <img src="images/pdf.png" width=32 height=32 />park_map_download.pdf</div>
          </div>
        </div>
      </div>
      <div class="row">
          <div class="col-md-12" >
            <div class="col-md-12 mainitem" style="text-align:left" >
              <h4>
              Contact us: <img src="images/facebook.png" width=32 height=32 />
              <img src="images/twitter.png" width=32 height=32 />
              <img src="images/instagram.png" width=32 height=32 />
              </h4>
              
              <div class="col-md-12" >
              Via Nazionale, 24 38080 Strembo (TN) 
              </div>
              <div class="col-md-12" >
                Mail: info@redstonepark.org
              </div>
              <div class="col-md-12 " >
                Phone: 203-781-3819
              </div>
            </div>
            
          </div>
      </div>
    </div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>